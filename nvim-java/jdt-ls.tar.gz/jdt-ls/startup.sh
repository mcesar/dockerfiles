#!/bin/sh
export JAVA_TOOL_OPTIONS='-javaagent:/jdt-ls/lombok.jar -Xbootclasspath/p:/jdt-ls/lombok.jar'
ps -ef | grep -e '-Declipse.application=org.eclipse.jdt.ls.core.id1' | xargs | cut -d ' ' -f 1 | xargs kill 2>/dev/null
java -Declipse.application=org.eclipse.jdt.ls.core.id1 -Dosgi.bundles.defaultStartLevel=4 -Declipse.product=org.eclipse.jdt.ls.core.product -Dlog.level=ALL -noverify -Xmx1G -jar /jdt-ls/plugins/org.eclipse.equinox.launcher_1.5.0.v20180207-1446.jar -configuration /jdt-ls/config_linux -data /src
